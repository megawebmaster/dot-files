TerronAI v204
-------------

0. Introduction
---------------
Terron is an AI written for OpenTTD - simulation game based upon the popular
 Transport Tycoon Deluxe.

Topic on tt-forums.net: http://www.tt-forums.net/viewtopic.php?f=65&t=54639

1. AI Settings description
--------------------------
"Use buses" - This setting defines how AI can uses buses. Possible options:
[No]
  AI will not use buses.
[Town-to-town transportation]
  AI is allowed to use buses to transport passengers between towns. In such case
  it will lose no opportunity to transport mail between same towns(even though
  formally mail requires trucks).
[Passengers transit into docks or airports]
  AI is allowed to use buses to transfer passengers from towns to nearby airport
  or dock stations. Highly recommended if AI is allowed to use planes but towns
  control noise level of airports.
[Mixed]
  Two previous options are considered enabled.

NewGRFs can add industries both "producing" and accepting passengers.
 For purpose of serving such industries buses are treated by AI as special form
 of trucks and AI ability to connect them are not subdued to this setting.
 Instead the very next setting value is used:

"Use trucks" - This setting defines how AI can uses trucks. Possible options:
[No]
  AI will not use trucks.
[Simple "greedy strategy"]
  Basically AI will try to build single most profitable point-to-point route it
  can find... Rinse and repeat. Simple but quite effective.
[Test "Delivery Tree" strategy]
  Test options so far. AI will plan and build entire road networks consisting of
  supply chains.
  However, this option requires more calculations(which means somewhat delayed
  AI start) and is not very useful with default industry set because raw goods
  (e.g. coal) just as profitable as goods. What's the point then? Partially
  this is a step to train networks, partially aesthetic reasons, but mainly FIRS
  NewGRF which changes cargo payment picture and adds many new cargo types as
  well.
  After completing(or failing to complete) all planned networks AI will switch
  to "greedy strategy" mode.

  ECS, while being similar to FIRS, alters basic game rules much more. AI does
  not have explicit instructions for such alterations. Even though AI will
  work with ECS, its performance will be not optimal and AI can make lot of
  stupid(from ECS game rules point of view) things.
[Mixed]
  This is "delivery tree with delay". AI will not try to build complicated stuff
  while poor. Planned networks construction will start only when month income
  hits certain crossbar. Until then AI can use "greedy strategy" though, which
  is why this option called 'mixed'.

"Max road routes length" - This setting defines maximal distance at which AI is
 allowed to connect towns or industries with roads. Greater value leads to more
 connection possibilities and generally more profitable routes.

AI's road section performance greatly depends on used road vehicle NewGRFs.
 Profit figures can be several times higher with e.g. eGRVTS or Long vehicles
 than with default vehicles set.

But let's move to air section.
"Use planes" - This setting defines whether AI can airplanes. Possible options:
[No]
  AI will not use airplanes.
[Yes, but not as first transport type]
  AI will be able to use airplanes. But first it must make some money with other
  transport types. This is mostly fail-safe option to ensure that AI will not go
  bankrupt when game starts with low initial loan.
[Yes]
  AI will be able to use airplanes right from the start.
In any case AI will not use helicopters or freight planes.

"Max airlines length" - This setting limits allowed planes travel distance
between AI airports.

"Use small airports" - This setting defines whether AI can build small airports.

"Airports maintenance cost" - Unfortunately currently AIs can't find out exact
 airport maintenance cost(or i'm missing something). This setting gives AI
 a hint about monthly payment rate per airport and allows operate properly.
 If you are not using av8 newgrf than set it to "Default game value".
 If you are using av8 newgrf than set it to "Av8 newGRF custom value". In such
 case you also must enable "Airport Maintenance Costs" option inside av8 config
 window(or AI will fail to act properly).

"Use ships" - This setting defines whether AI can ships. Same as for planes:
[No]
  AI will not use ships.
[Yes, but not as first transport type]
  AI will be able to use ships after establishing another source of profit.
[Yes]
  AI will be able to use ships right from the start.

"Max water routes length" - Defines how far AI ships can travel.

"Use slow ships" - Allows/disallows usage of ships with max speed lesser than
 50 km/h. Slow ships are kind of useless for AI though. Notice that fast ships
 "invention" happens around 1970(or slightly earlier with NewGRFs) which means
 that AI most likely won't use ships until then.
The game becomes slower with ships, so AI won't build new docks if it has more
 than 50 ships.

"Use free money to fund new buildings in the towns with AI company statue" -
 pretty self-explanatory. Allows to dump AI millions into town buildings
 funding. Some moments though:
 * AI company statue must be built in the town 
 * Town will be funded until it hits 7000 population cap.
 * Company rating increase action(simply bribing) has higher priority, thus all
   meaningful towns must be bribed before funding will start. And this is a lot
   of time and money.
 * Single other option to spend millions available to AI is exclusive transport
   rights purchasing. Thus when you disable this option you're automatically
   increasing AI's exclusive rights purchasing ability.

2. License
----------
This AI is released under GPLv2 license.
This AI reuses code from AdmiralAIv22.
