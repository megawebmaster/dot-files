
-- What is this --
This library includes an Script Communication Protocol (SCP) Client for 
AIs to 
- identify if they play a NoCarGoal game
- get the NoCarGoal goals (cargos, transport goal, amount transported)

Additionally the library contains
- helpers to check if a given cargo is a goal cargo or not

-- API docs --
See main.nut of the library which have commented public members

-- Library design idea --
The idea is that other GSes may provide SCPClient_<some other lib>, and 
that AIs will want to include more than one of them. Therefore this 
library do not initialize or include the SCP library. Instead you pass
an instance of it to the SCPClient constructor.

-- Examples --
If you want an example, you can check out CluelessPlus which is an AI 
that uses this library.

