Please keep in mind this software is release under GNU Affero GPL
Read this faq, specially this entry for more info : http://www.gnu.org/licenses/gpl-faq.html#UnreleasedMods

The source code include a modified version of Game Script "Neighbours are important". (C) Zuu. Release under GPLv2
You can find the modified version source code attach to the directory /scp-gstest in the scp source code.

